package com.bhsconsultants.vonneumanns.exceptions;

public class InsufficientQuantityException extends Exception 
{	
	public InsufficientQuantityException() {
	}
	
	
	// Not used really...
	public InsufficientQuantityException(String message)
	{
		super(message);
	}	
}
